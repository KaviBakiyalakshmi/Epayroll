export class Attendance {
    id : number=0;
    employeeid : String='';
    name : string='';
    starttime : string='';
    endtime : string='';
    date: string='';
    status : string ='';
    
}