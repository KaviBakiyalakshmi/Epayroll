export class Leaves {
    id : number=0;
    employeeid: string;
    startdate: String;
    enddate: String;
    reason: String;
    status: String;
}