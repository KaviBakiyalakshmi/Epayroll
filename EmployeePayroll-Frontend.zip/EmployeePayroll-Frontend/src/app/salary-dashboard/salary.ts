export class Salary{
    id:number;
    employeeid:String;
    name:String;
    month:String;
    year:String;
    salary:String;
}