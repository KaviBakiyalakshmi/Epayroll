export class User {
  id: number;
  employeeid: String;
  name: String;
  mobile: String;
  email: String;
  gender: String;
  dob: String;
  doj:String;
  password:String;
  designation: String;
  role:String;
  schedule: String;
}
